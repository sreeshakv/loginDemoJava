package com.loginandregistrationdemo.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.loginandregistrationdemo.database.Dao;
import com.loginandregistrationdemo.model.User;


/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Read the inputs that are provided in the form
		String name = request.getParameter("name");
		String mail = request.getParameter("mail");
		String mobile = request.getParameter("mobnum");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		// Create a model object - User object
		User user = new User();
		
		// Set the inputs as parameters to the model object
		user.setName(name);
		user.setMail(mail);
		user.setMobile(mobile);
		user.setUsername(username);
		user.setPassword(password);

		Dao dao = new Dao();
		int rows_affected = dao.registerUser(user);
		
		RequestDispatcher rd = null;
		if (rows_affected >0)
		{
			request.setAttribute("msg", "Registration Success");
			rd = request.getRequestDispatcher("/login.jsp");
			rd.forward(request, response);
		}
		else
		{
			request.setAttribute("msg", "Registration Failed... Try again");
			rd = request.getRequestDispatcher("/registration.jsp");
			rd.forward(request, response);
		}
		
	}
}
