package com.loginandregistrationdemo.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.loginandregistrationdemo.model.User;

public class Dao 
{
	private Connection conn = null;
	private PreparedStatement ps = null; 
	private ResultSet rs = null;
	
	public int registerUser(User user) {
		
		String sql = "insert into Users(NAME,USERNAME,MAIL,MOBILE,PASSWORD) values (?,?,?,?,?)";
		int i = 0 ;
		try {
			conn = DBConnector.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getUsername());
			ps.setString(3, user.getMail());
			ps.setString(4, user.getMobile());
			ps.setString(5, user.getPassword());

			i = ps.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
		DBConnector.closeStatement(ps);
		DBConnector.closeConnection(conn);
		}
		return i;
	}
	
	public User verifyUser(String username,String pwd) throws SQLException 
	{
		String sql = "select * from Users where USERNAME='"+username+"' and PASSWORD='"+pwd+"'";
		User user = null;
		try {
			conn = DBConnector.getConnection();
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setUserid(rs.getInt("USERID"));
				user.setName(rs.getString("NAME"));
				user.setMail(rs.getString("MAIL"));
				user.setMobile(rs.getString("MOBILE"));

			}
	}catch(SQLException e) {
		e.printStackTrace();
	}finally {
	try {
		rs.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	DBConnector.closeStatement(ps);
	DBConnector.closeConnection(conn);
	}
		return user;
	}

	

}
